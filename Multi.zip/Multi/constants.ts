import type { TimerStage } from './types';

export const TIMER_STAGES: TimerStage[] = [
  { label: '8(Forehead)', duration: 10 * 60 },
  { label: '7(L)', duration: 3 * 60 },
  { label: '7(R)', duration: 3 * 60 },
  { label: '7+(L)', duration: 3 * 60 },
  { label: '7+(R)', duration: 3 * 60 },
  { label: '6(L)', duration: 3 * 60 },
  { label: '6(R)', duration: 3 * 60 },
  { label: '1(L)', duration: 5 * 60 },
  { label: '1(R)', duration: 5 * 60 },
  { label: 'Extra 1', duration: 3 * 60 },
  { label: 'Extra 2', duration: 3 * 60 },
  { label: 'Extra 3', duration: 3 * 60 },
  { label: 'Extra 4', duration: 3 * 60 },
];
