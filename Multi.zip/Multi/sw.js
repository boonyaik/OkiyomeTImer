// Define a unique cache name for this version of the app.
// Change this name to force the service worker to update and re-cache files.
const CACHE_NAME = 'interval-timer-cache-v1';

// List all the files and resources that need to be cached for offline use.
const URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/index.tsx',
  '/App.tsx',
  '/constants.ts',
  '/types.ts',
  '/components/icons.tsx',
  '/manifest.json',
  '/vite.svg',
  'https://cdn.tailwindcss.com',
  'https://esm.sh/react@^19.1.0',
  'https://esm.sh/react-dom@^19.1.0/client',
  'https://esm.sh/react@^19.1.0/jsx-runtime'
];

// --- INSTALL Event ---
// This event is fired when the service worker is first installed.
// We open a cache and add all our specified URLs to it.
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache and caching files');
        return cache.addAll(URLS_TO_CACHE);
      })
      .catch(err => {
        console.error('Failed to cache files during install:', err);
      })
  );
});

// --- FETCH Event ---
// This event is fired for every single network request made by the page.
// We intercept the request and respond with the cached version if available.
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((cachedResponse) => {
        // If a cached response is found, return it.
        if (cachedResponse) {
          return cachedResponse;
        }
        // If the resource is not in the cache, fetch it from the network.
        return fetch(event.request);
      })
  );
});

// --- ACTIVATE Event ---
// This event is fired when the service worker is activated.
// It's a good place to clean up old caches from previous versions.
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
