import React, {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from 'react';
import { TIMER_STAGES } from './constants';
import {
  PlayIcon,
  PauseIcon,
  ResetIcon,
  VolumeOnIcon,
  VolumeOffIcon,
} from './components/icons';

const formatTime = (timeInSeconds: number) => {
  const minutes = Math.floor(timeInSeconds / 60);
  const seconds = timeInSeconds % 60;
  return {
    minutes: String(minutes).padStart(2, '0'),
    seconds: String(seconds).padStart(2, '0'),
  };
};

const BEEP_AUDIO_SRC = 'audio/audio.mp3';

const App: React.FC = () => {
  /* ─────────────────────────────────────────────
     State & refs
  ────────────────────────────────────────────── */
  const [currentTimerIndex, setCurrentTimerIndex] = useState<number>(0);
  const [time, setTime] = useState<number>(0); // count‑up per stage
  const [isPaused, setIsPaused] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // NEW ▶ remembers when the very first Start click happened
  const startTimeRef = useRef<number | null>(null);
  // NEW ▶ wall‑clock that ticks every second once started
  const [now, setNow] = useState<number>(Date.now());

  const wakeLockRef = useRef<any | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentStage = useMemo(() => TIMER_STAGES[currentTimerIndex], [currentTimerIndex]);
  const initialDuration = currentStage.duration;
  const hasStageEnded = time >= initialDuration;
  const isFinished = hasStageEnded && currentTimerIndex >= TIMER_STAGES.length - 1;

  /* ─────────────────────────────────────────────
     Orientation lock – run once
  ────────────────────────────────────────────── */
  useEffect(() => {
    const lockOrientation = async () => {
      if (screen.orientation?.lock) {
        try { await screen.orientation.lock('landscape'); } catch (_) {}
      }
    };
    lockOrientation();
  }, []);

  /* ─────────────────────────────────────────────
     Wake lock
  ────────────────────────────────────────────── */
  useEffect(() => {
    const isTimerActive = !isPaused && !isFinished;
    const acquireWakeLock = async () => {
      if ('wakeLock' in navigator) {
        try {
          wakeLockRef.current = await navigator.wakeLock.request('screen');
          wakeLockRef.current.addEventListener('release', () => (wakeLockRef.current = null));
        } catch (_) {}
      }
    };
    const releaseWakeLock = async () => {
      if (wakeLockRef.current) {
        await wakeLockRef.current.release();
        wakeLockRef.current = null;
      }
    };
    if (isTimerActive) acquireWakeLock();
    else releaseWakeLock();
    return releaseWakeLock;
  }, [isPaused, isFinished]);

  /* ─────────────────────────────────────────────
     Timer – count‑up per stage
  ────────────────────────────────────────────── */
  useEffect(() => {
    if (isPaused || hasStageEnded) return;
    const id = setInterval(() => setTime((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, [isPaused, hasStageEnded]);

  /* ─────────────────────────────────────────────
     Wall‑clock ticker – overall elapsed time
  ────────────────────────────────────────────── */
  useEffect(() => {
    if (startTimeRef.current === null) return; // haven’t started yet
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [startTimeRef.current]);

  /* ─────────────────────────────────────────────
     Stage change
  ────────────────────────────────────────────── */
  useEffect(() => {
    if (!hasStageEnded) return;
    if (audioRef.current && !isMuted) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
    }
    if (currentTimerIndex < TIMER_STAGES.length - 1) {
      setCurrentTimerIndex((i) => i + 1);
      setTime(0);
    } else {
      setIsPaused(true);
    }
  }, [hasStageEnded, currentTimerIndex, isMuted]);

  /* ─────────────────────────────────────────────
     Derived data – stage & total clocks
  ────────────────────────────────────────────── */
  const { minutes, seconds } = formatTime(Math.min(time, initialDuration));
  const progress = useMemo(() => Math.min(time / initialDuration, 1), [time, initialDuration]);
  const isPristine = time === 0;

  // ▶ total clock (real‑world time since first Start)
  const totalSecondsElapsed = startTimeRef.current
    ? Math.floor((now - startTimeRef.current) / 1000)
    : 0;
  const { minutes: totalMin, seconds: totalSec } = formatTime(totalSecondsElapsed);

  /* ─────────────────────────────────────────────
     Handlers
  ────────────────────────────────────────────── */
  const handleStageSelect = useCallback((index: number) => {
    setCurrentTimerIndex(index);
    setTime(0);
    setIsPaused(true);
    //startTimeRef.current = null; // reset overall clock when manually selecting a stage
  }, []);

  const handleMuteToggle = () => setIsMuted((m) => !m);

  const handlePrimaryClick = useCallback(() => {
    if (isFinished) {
      handleStageSelect(0);
    } else {
      // record the very first Start time
      if (startTimeRef.current === null) {
        startTimeRef.current = Date.now();
        setNow(startTimeRef.current); // align display immediately
      }
      setIsPaused((p) => !p);
    }
  }, [isFinished, handleStageSelect]);

  const handleResetClick = () => {
    setTime(0);
    setIsPaused(true);
    startTimeRef.current = null; // restart overall clock
  };

  /* ─────────────────────────────────────────────
     Primary button label
  ────────────────────────────────────────────── */
  let primaryLabel;
  if (isFinished) primaryLabel = (<><ResetIcon className="w-6 h-6 mr-2"/>Start Over</>);
  else if (isPaused) primaryLabel = (<><PlayIcon className="w-6 h-6 mr-2"/>{isPristine ? 'Start' : 'Resume'}</>);
  else primaryLabel = (<><PauseIcon className="w-6 h-6 mr-2"/>Pause</>);

  /* ─────────────────────────────────────────────
     Render
  ────────────────────────────────────────────── */
  return (
    <main className="bg-gray-900 text-white min-h-screen flex flex-col items-center justify-center p-4 font-sans antialiased overflow-hidden">
      <audio ref={audioRef} src={BEEP_AUDIO_SRC} preload="auto" />

      <div className="w-full max-w-4xl mx-auto flex flex-col items-center text-center">
        {/* Title  */}
        <div className="landscape:hidden">
          <h1 className="text-4xl font-bold text-indigo-400 mb-2">Okiyome Timer</h1>
          <p className="text-lg text-gray-400 mb-8">Select a point or press start to begin.</p>
        </div>
  

        {/* Timer Circle */}
        <div className="relative w-72 h-72 sm:w-80 sm:h-80 landscape:w-[45vh] landscape:h-[45vh] flex items-center justify-center mb-4 landscape:mb-2">

          <div className="z-10 flex flex-col items-center">
            {/* Labels row */}
            <div className="flex flex-wrap gap-4 items-center text-xl sm:text-xl landscape:text-[5vh] font-semibold text-gray-400 mb-1 capitalize">
              <span>Point: <span className="text-indigo-400">{currentStage.label}</span></span>
              <span>Total: <span className="text-indigo-400">{totalMin}:{totalSec}</span></span>
            </div>

            {/* Clock */}
            <div className="font-mono text-9xl sm:text-12xl landscape:text-[35vh] font-bold tracking-tighter">
              <span>{minutes}</span>
              <span className={isPaused ? '' : 'animate-pulse'}>:</span>
              <span>{seconds}</span>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex space-x-4 mb-6 landscape:mb-4">
  
          <select id="stageSelect" value={currentTimerIndex} onChange={(e)=>handleStageSelect(Number(e.target.value))} className="w-full bg-gray-800 text-gray-200 font-mono font-bold text-sm sm:text-base px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-gray-700 transition-colors hidden landscape:block">
           {TIMER_STAGES.map((s,i)=>(<option key={s.label} value={i}>{s.label}</option>))}
          </select> 
          <button onClick={handlePrimaryClick} className={`flex items-center justify-center px-8 py-4 rounded-full text-xl font-bold transition-all duration-200 ease-in-out shadow-lg transform hover:scale-105 ${isPaused ? 'bg-indigo-600 hover:bg-indigo-500' : 'bg-yellow-500 hover:bg-yellow-400 text-gray-900'}`}>{primaryLabel}</button>
          <button onClick={handleResetClick} disabled={isPristine && isPaused} className="flex items-center justify-center p-4 rounded-full text-xl font-bold bg-gray-700 hover:bg-gray-600 text-white transition-all duration-200 ease-in-out shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transform enabled:hover:scale-105" aria-label="Reset Timer"><ResetIcon className="w-6 h-6"/></button>
          <button onClick={handleMuteToggle} className="flex items-center justify-center p-4 rounded-full text-xl font-bold bg-gray-700 hover:bg-gray-600 text-white transition-all duration-200 ease-in-out shadow-lg transform hover:scale-105" aria-label={isMuted?'Unmute':'Mute'}>{isMuted ? <VolumeOffIcon className="w-6 h-6"/> : <VolumeOnIcon className="w-6 h-6"/>}</button>
        </div>
        
        
       <div className="w-full landscape:hidden">
            <h2 className="text-lg font-semibold text-gray-300 mb-4 landscape:hidden">Points</h2>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
            {TIMER_STAGES.map((stage, index) => (
                <button
                key={`${stage.label}-${index}`}
                onClick={() => handleStageSelect(index)}
                className={`px-3 py-2 sm:py-4 rounded-lg font-mono font-bold text-base sm:text-lg transition-colors duration-200 ${
                    currentTimerIndex === index
                    ? 'bg-indigo-500 text-white ring-2 ring-indigo-300'
                    : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                }`}
                >
                {stage.label}
                </button>
            ))}
            </div>
        </div>
        

      </div>
    </main>
  );
};

export default App;
